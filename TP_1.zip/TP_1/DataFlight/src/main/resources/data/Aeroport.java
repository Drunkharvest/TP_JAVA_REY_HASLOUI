package TP3D;

public class Aeroport {
    private String iataCode;
    private String name;
    private String city;
    private String country;
    private double latitude;
    private double longitude;

    public Aeroport(String iataCode, String name, String city, String country, double latitude, double longitude) {
        this.iataCode = iataCode;
        this.name = name;
        this.city = city;
        this.country = country;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    // Getters
    public String getIataCode() { return iataCode; }
    public String getName() { return name; }
    public String getCity() { return city; }
    public String getCountry() { return country; }
    public double getLatitude() { return latitude; }
    public double getLongitude() { return longitude; }

    public double calculDistance(Aeroport a) {
        double theta1 = Math.toRadians(this.latitude);
        double theta2 = Math.toRadians(a.latitude);
        double phi1 = Math.toRadians(this.longitude);
        double phi2 = Math.toRadians(a.longitude);
        
        double norme = Math.pow(theta2 - theta1, 2) + 
                      Math.pow((phi2 - phi1) * Math.cos((theta2 + theta1) / 2), 2);
        return norme;
    }

    @Override
    public String toString() {
        return String.format("%s (%s, %s) - %.4f, %.4f", 
                           name, iataCode, city, latitude, longitude);
    }
}
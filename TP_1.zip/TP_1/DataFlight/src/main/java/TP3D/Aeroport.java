package TP3D;

public class Aeroport {
    private final String ident;
    private final String name;
    private final String isoCountry;
    private final String municipality;
    private final double latitude;
    private final double longitude;

    public Aeroport(String ident, String name, String isoCountry, String municipality,
                    double latitude, double longitude) {
        this.ident = ident;
        this.name = name;
        this.isoCountry = isoCountry;
        this.municipality = municipality;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getIdent() {
        return ident;
    }

    public String getName() {
        return name;
    }

    public String getIsoCountry() {
        return isoCountry;
    }

    public String getMunicipality() {
        return municipality;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    @Override
    public String toString() {
        return String.format("%s (%s) - %s, %s [%.4f, %.4f]",
                name, ident, municipality, isoCountry, latitude, longitude);
    }
}
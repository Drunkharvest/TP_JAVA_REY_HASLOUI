package TP3D;

import javafx.scene.image.Image;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Sphere;
import javafx.geometry.Point2D;

public class Earth extends Sphere {
    private final PhongMaterial earthMaterial;

    public Earth() {
        super(300);
        System.out.println("=== EARTH CONSTRUCTOR RUNS ===");

        earthMaterial = new PhongMaterial();

        // charge l'image depuis resources
        String imgPath = "/data/earth_lights_4800.png";
        try {
            Image earthImg = new Image(Earth.class.getResourceAsStream(imgPath));
            System.out.println("EARTH IMG URL = " + Earth.class.getResource(imgPath));
            earthMaterial.setDiffuseMap(earthImg);
        } catch (Exception e) {
            System.out.println("❌ Impossible de charger " + imgPath);
            e.printStackTrace();
        }

        this.setMaterial(earthMaterial);
    }

    public Point2D latLonToTexCoords(double latitude, double longitude) {
        // texture coords: u = (lon + 180) / 360, v = (90 - lat) / 180
        double u = (longitude + 180.0) / 360.0;
        double v = (90.0 - latitude) / 180.0;
        return new Point2D(u, v);
    }

    public Point2D texCoordsToLatLon(Point2D texCoords) {
        double u = texCoords.getX();
        double v = texCoords.getY();
        double longitude = u * 360.0 - 180.0;
        double latitude = 90.0 - v * 180.0;
        return new Point2D(latitude, longitude);
    }
}
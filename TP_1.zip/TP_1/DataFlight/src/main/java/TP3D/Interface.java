package TP3D;

import javafx.application.Application;
import javafx.scene.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.PickResult;
import javafx.scene.paint.Color;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.geometry.Point2D;

public class Interface extends Application {

    private double mouseOldX, mouseOldY;
    private final Rotate rotateX = new Rotate(0, Rotate.X_AXIS);
    private final Rotate rotateY = new Rotate(0, Rotate.Y_AXIS);
    private Point2D pickTexCoords;

    private World world;
    private Earth earth;

    @Override
    public void start(Stage primaryStage) {
        System.out.println("MAIN OK");

        // charge le monde (CSV)
        world = new World();

        // crée la Terre
        earth = new Earth();
        earth.getTransforms().addAll(rotateX, rotateY);

        // caméra
        PerspectiveCamera camera = new PerspectiveCamera(true);
        camera.setTranslateZ(-1000);
        camera.setNearClip(0.1);
        camera.setFarClip(2000.0);
        camera.setFieldOfView(35);

        // groupe racine
        Group root = new Group(earth);

        // scène
        Scene scene = new Scene(root, 800, 600, true);
        scene.setFill(Color.BLACK);
        scene.setCamera(camera);

        // gestion souris
        scene.setOnMousePressed(this::handleMousePressed);
        scene.setOnMouseDragged(this::handleMouseDragged);
        scene.setOnMouseClicked(this::handleMouseClicked);

        primaryStage.setTitle("DataFlight - 3D Earth");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void handleMousePressed(MouseEvent event) {
        mouseOldX = event.getSceneX();
        mouseOldY = event.getSceneY();
    }

    private void handleMouseDragged(MouseEvent event) {
        double deltaX = event.getSceneX() - mouseOldX;
        double deltaY = event.getSceneY() - mouseOldY;

        rotateY.setAngle(rotateY.getAngle() + deltaX * 0.5);
        rotateX.setAngle(rotateX.getAngle() - deltaY * 0.5);

        mouseOldX = event.getSceneX();
        mouseOldY = event.getSceneY();
    }

    private void handleMouseClicked(MouseEvent event) {
        PickResult pickResult = event.getPickResult();
        if (pickResult.getIntersectedNode() == earth) {
            pickTexCoords = pickResult.getIntersectedTexCoord();
            if (pickTexCoords != null) {
                Point2D latLon = earth.texCoordsToLatLon(pickTexCoords);
                double latitude = latLon.getX();
                double longitude = latLon.getY();

                System.out.printf("Clicked on (%.1f,%.1f) → lat=%.2f, lon=%.2f%n",
                        event.getSceneX(), event.getSceneY(), latitude, longitude);

                Aeroport nearest = world.findNearest(latitude, longitude);
                if (nearest != null) {
                    System.out.println("  → Aéroport le plus proche: " + nearest);
                }
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
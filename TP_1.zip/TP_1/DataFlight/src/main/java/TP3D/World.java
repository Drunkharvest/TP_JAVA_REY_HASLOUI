package TP3D;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class World {
    private final List<Aeroport> aeroports = new ArrayList<>();

    // pattern pour extraire les 2 derniers nombres de la ligne (lon, lat)
    private static final Pattern LAST_TWO_DOUBLES =
            Pattern.compile("(-?\\d+(?:\\.\\d+)?)\\s*,\\s*(-?\\d+(?:\\.\\d+)?)(?!.*-?\\d)");

    public World() {
        String resourcePath = "/data/airport-codes_no_comma.csv";
        System.out.println("=== WORLD CONSTRUCTOR RUNS === resource=" + resourcePath);

        try (InputStream is = World.class.getResourceAsStream(resourcePath)) {
            if (is == null) {
                throw new IllegalStateException("❌ CSV introuvable dans resources: " + resourcePath +
                        "\n   → Mets-le dans src/main/resources/data/");
            }

            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String header = br.readLine(); // saute l'en-tête
                if (header == null) return;

                System.out.println("HEADER=" + header);

                String line;
                int count = 0;
                while ((line = br.readLine()) != null) {
                    line = line.trim();
                    if (line.isEmpty()) continue;

                    // ignore lignes markdown si jamais
                    if (line.startsWith("|")) continue;

                    // split par virgule pour récupérer les champs de base
                    String[] parts = line.split(",");
                    if (parts.length < 8) continue;

                    String ident = parts[0].trim();
                    String name = parts[2].trim();
                    String isoCountry = parts[5].trim();
                    String municipality = parts[7].trim();

                    // extraction robuste de lon, lat (les 2 derniers nombres de la ligne)
                    double lon, lat;
                    Matcher m = LAST_TWO_DOUBLES.matcher(line);
                    if (!m.find()) {
                        continue; // pas de coordonnées valides
                    }
                    lon = Double.parseDouble(m.group(1));
                    lat = Double.parseDouble(m.group(2));

                    Aeroport a = new Aeroport(ident, name, isoCountry, municipality, lat, lon);
                    aeroports.add(a);
                    count++;
                }

                System.out.println("✅ " + count + " aéroports chargés");
            }
        } catch (Exception e) {
            System.out.println("❌ Erreur lecture CSV: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public List<Aeroport> getAeroports() {
        return aeroports;
    }

    public Aeroport findNearest(double latitude, double longitude) {
        Aeroport nearest = null;
        double minDist = Double.MAX_VALUE;

        for (Aeroport a : aeroports) {
            double dist = distance(latitude, longitude, a.getLatitude(), a.getLongitude());
            if (dist < minDist) {
                minDist = dist;
                nearest = a;
            }
        }
        return nearest;
    }

    public Aeroport findByIdent(String ident) {
        if (ident == null) return null;
        for (Aeroport a : aeroports) {
            if (a.getIdent() != null && a.getIdent().equalsIgnoreCase(ident.trim())) {
                return a;
            }
        }
        return null;
    }

    private double distance(double lat1, double lon1, double lat2, double lon2) {
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return 6371 * c; // rayon Terre en km
    }
}
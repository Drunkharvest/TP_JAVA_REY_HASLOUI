package TP3D;

public class TestWorld {
    public static void main(String[] args) {
        World w = new World();

        System.out.println("Nb aéroports = " + w.getAeroports().size());

        // exemple : trouver l'aéroport le plus proche de Paris (approx)
        Aeroport nearest = w.findNearest(48.8566, 2.3522);
        System.out.println("Nearest to Paris = " + nearest);

        // exemple : chercher par ident (si tu veux)
        Aeroport a = w.findByIdent("LFPG"); // adapte à un ident existant
        System.out.println("Find LFPG = " + a);

        // exemple : distance km (méthode publique ci-dessous si tu l’ajoutes)
        // System.out.println("Dist = " + w.distanceKm(48.8566, 2.3522, nearest.getLatitude(), nearest.getLongitude()));
    }
}